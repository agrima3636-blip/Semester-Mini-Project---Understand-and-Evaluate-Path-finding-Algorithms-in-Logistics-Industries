import networkx as nx
import numpy as np
from geopy.distance import geodesic
import heapq

class DijkstraRouter:
    """Dijkstra's algorithm implementation for route optimization"""
    
    def __init__(self, dataset=None, api_client=None):
        self.dataset = dataset
        self.api_client = api_client
        self.graph = None
        
    def build_graph(self, points):
        """Build a graph from the given points"""
        G = nx.Graph()
        
        # Add nodes
        for i, point in enumerate(points):
            G.add_node(i, pos=point)
        
        # Add edges with distances as weights
        for i in range(len(points)):
            for j in range(i + 1, len(points)):
                distance = geodesic(points[i], points[j]).kilometers
                G.add_edge(i, j, weight=distance)
        
        return G
    
    def find_route(self, start_point, end_point):
        """Find the optimal route using Dijkstra's algorithm"""
        try:
            # If API client is available, use real routing
            if self.api_client:
                return self._find_route_with_api(start_point, end_point)
            
            # Otherwise, use graph-based approach with dataset
            if self.dataset is not None:
                return self._find_route_with_dataset(start_point, end_point)
            
            # Fallback: direct route
            return self._direct_route(start_point, end_point)
            
        except Exception as e:
            raise Exception(f"Dijkstra routing failed: {str(e)}")
    
    def _find_route_with_api(self, start_point, end_point):
        """Find route using API service"""
        route_data = self.api_client.get_route(start_point, end_point, profile='driving-car')
        
        return {
            'route': route_data['geometry'],
            'distance_km': route_data['distance'] / 1000,
            'time_minutes': route_data['duration'] / 60,
            'adaptability_score': 0.7  # Dijkstra is moderately adaptable
        }
    
    def _find_route_with_dataset(self, start_point, end_point):
        """Find route using dataset points and Dijkstra's algorithm"""
        # Create points list including start, end, and dataset points
        points = [start_point, end_point]
        if len(self.dataset) > 0:
            dataset_points = [[row['lat'], row['lon']] for _, row in self.dataset.iterrows()]
            points.extend(dataset_points[:50])  # Limit to 50 points for performance
        
        # Build graph
        self.graph = self.build_graph(points)
        
        # Find shortest path using Dijkstra
        try:
            path = nx.shortest_path(self.graph, source=0, target=1, weight='weight')
            path_length = nx.shortest_path_length(self.graph, source=0, target=1, weight='weight')
        except nx.NetworkXNoPath:
            # Direct route if no path found
            return self._direct_route(start_point, end_point)
        
        # Convert path to coordinates
        route_coords = []
        for node in path:
            pos = self.graph.nodes[node]['pos']
            route_coords.append(pos)
        
        # Calculate estimated time (assuming 50 km/h average speed)
        time_minutes = (path_length / 50) * 60
        
        return {
            'route': route_coords,
            'distance_km': path_length,
            'time_minutes': time_minutes,
            'adaptability_score': 0.7
        }
    
    def _direct_route(self, start_point, end_point):
        """Calculate direct route between two points"""
        distance = geodesic(start_point, end_point).kilometers
        time_minutes = (distance / 50) * 60  # Assuming 50 km/h average speed
        
        return {
            'route': [start_point, end_point],
            'distance_km': distance,
            'time_minutes': time_minutes,
            'adaptability_score': 0.5  # Direct route has low adaptability
        }
    
    def _dijkstra_custom(self, graph, start, end):
        """Custom Dijkstra implementation for educational purposes"""
        distances = {node: float('infinity') for node in graph.nodes()}
        distances[start] = 0
        previous = {node: None for node in graph.nodes()}
        unvisited = [(0, start)]
        visited = set()
        
        while unvisited:
            current_distance, current = heapq.heappop(unvisited)
            
            if current in visited:
                continue
                
            visited.add(current)
            
            if current == end:
                break
            
            for neighbor in graph.neighbors(current):
                if neighbor in visited:
                    continue
                
                edge_weight = graph[current][neighbor]['weight']
                distance = current_distance + edge_weight
                
                if distance < distances[neighbor]:
                    distances[neighbor] = distance
                    previous[neighbor] = current
                    heapq.heappush(unvisited, (distance, neighbor))
        
        # Reconstruct path
        path = []
        current = end
        while current is not None:
            path.append(current)
            current = previous[current]
        
        return list(reversed(path))
