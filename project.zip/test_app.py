import streamlit as st

st.title("Test App")
st.write("If you see this, the app is working!")
st.button("Click me")
