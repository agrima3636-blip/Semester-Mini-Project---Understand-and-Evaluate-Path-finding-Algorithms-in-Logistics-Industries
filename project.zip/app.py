import streamlit as st
import pandas as pd
import folium
from streamlit_folium import st_folium
import time
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from algorithms.dijkstra import DijkstraRouter
from algorithms.astar import AStarRouter
from algorithms.genetic import GeneticRouter
from algorithms.reinforcement import RLRouter
from utils.map_utils import create_base_map, add_route_to_map
from utils.data_utils import generate_sample_data
from utils.api_client import OpenRouteServiceClient

st.set_page_config(
    page_title="Route Optimization Comparison Tool",
    page_icon="🗺️",
    layout="wide",
    initial_sidebar_state="expanded"
)

if 'start_point' not in st.session_state:
    st.session_state.start_point = None
if 'end_point' not in st.session_state:
    st.session_state.end_point = None
if 'dataset' not in st.session_state:
    st.session_state.dataset = None
if 'routes_calculated' not in st.session_state:
    st.session_state.routes_calculated = False
if 'results' not in st.session_state:
    st.session_state.results = {}

def main():
    st.title("🗺️ Route Optimization Comparison Tool")
    st.markdown("Compare Dijkstra, A*, Genetic Algorithm, and Reinforcement Learning routing algorithms")
    
    with st.sidebar:
        st.header("Configuration")
        
        api_key = st.text_input(
            "OpenRouteService API Key (Optional)", 
            value="",
            type="password",
            help="Get free API key from openrouteservice.org - 2000 requests/day"
        )
        
        st.markdown("---")
        st.subheader("Dataset Upload")
        
        uploaded_file = st.file_uploader(
            "Upload CSV (lat/lon or drop_latitude/drop_longitude)",
            type=['csv'],
            help="CSV with location coordinates",
            key="csv_uploader"
        )
        
        if uploaded_file is not None:
            try:
                df = pd.read_csv(uploaded_file)
                st.write("Columns found:", df.columns.tolist())
                
                lat_options = [col for col in df.columns if 'lat' in col.lower()]
                lon_options = [col for col in df.columns if 'lon' in col.lower() or 'lng' in col.lower()]
                
                lat_col = st.selectbox("Latitude column", options=lat_options if lat_options else df.columns.tolist())
                lon_col = st.selectbox("Longitude column", options=lon_options if lon_options else df.columns.tolist())
                
                if st.button("Load Dataset"):
                    df_clean = df[[lat_col, lon_col]].copy()
                    df_clean.columns = ['lat', 'lon']
                    df_clean = df_clean.dropna()
                    st.session_state.dataset = df_clean
                    st.success(f"Loaded {len(df_clean)} locations!")
                    st.rerun()
                    
            except Exception as e:
                st.error(f"Error: {str(e)}")
        
        if st.button("Generate Sample Dataset"):
            st.session_state.dataset = generate_sample_data(50)
            st.success("Sample dataset generated!")
            st.rerun()
        
        if st.session_state.dataset is not None:
            st.info(f"Dataset: {len(st.session_state.dataset)} points loaded")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Interactive Map - Click to Select Start/End Points")
        
        m = create_base_map()
        
        if st.session_state.dataset is not None:
            df = st.session_state.dataset
            for idx, row in df.iterrows():
                try:
                    lat_val = float(row['lat'])
                    lon_val = float(row['lon'])
                    folium.CircleMarker(
                        location=[lat_val, lon_val],
                        radius=3,
                        popup=f"Point: {lat_val:.4f}, {lon_val:.4f}",
                        color='blue',
                        fill=True
                    ).add_to(m)
                except:
                    continue
        
        if st.session_state.start_point:
            folium.Marker(
                location=st.session_state.start_point,
                popup="Start",
                icon=folium.Icon(color='green', icon='play')
            ).add_to(m)
        
        if st.session_state.end_point:
            folium.Marker(
                location=st.session_state.end_point,
                popup="End", 
                icon=folium.Icon(color='red', icon='stop')
            ).add_to(m)
        
        map_data = st_folium(m, width=800, height=500, key="main_map")
        
        if map_data and map_data.get('last_clicked'):
            clicked = map_data['last_clicked']
            if clicked and 'lat' in clicked and 'lng' in clicked:
                if not st.session_state.start_point:
                    st.session_state.start_point = [clicked['lat'], clicked['lng']]
                    st.rerun()
                elif not st.session_state.end_point:
                    st.session_state.end_point = [clicked['lat'], clicked['lng']]
                    st.rerun()
    
    with col2:
        st.subheader("Route Selection")
        
        with st.expander("Manual Input"):
            start_lat = st.number_input("Start Lat", value=51.505 if not st.session_state.start_point else st.session_state.start_point[0], format="%.6f")
            start_lon = st.number_input("Start Lon", value=-0.09 if not st.session_state.start_point else st.session_state.start_point[1], format="%.6f")
            end_lat = st.number_input("End Lat", value=51.515 if not st.session_state.end_point else st.session_state.end_point[0], format="%.6f")
            end_lon = st.number_input("End Lon", value=-0.1 if not st.session_state.end_point else st.session_state.end_point[1], format="%.6f")
            
            if st.button("Set Coordinates"):
                st.session_state.start_point = [start_lat, start_lon]
                st.session_state.end_point = [end_lat, end_lon]
                st.rerun()
        
        if st.session_state.start_point:
            st.success(f"✅ Start: {st.session_state.start_point[0]:.4f}, {st.session_state.start_point[1]:.4f}")
        else:
            st.info("👆 Click map for start point")
        
        if st.session_state.end_point:
            st.success(f"✅ End: {st.session_state.end_point[0]:.4f}, {st.session_state.end_point[1]:.4f}")
        else:
            st.info("👆 Click map for end point")
        
        if st.button("🔄 Reset Points"):
            st.session_state.start_point = None
            st.session_state.end_point = None
            st.session_state.routes_calculated = False
            st.session_state.results = {}
            st.rerun()
        
        st.subheader("Algorithm Selection")
        alg_dijkstra = st.checkbox("Dijkstra's Algorithm", value=True)
        alg_astar = st.checkbox("A* Algorithm", value=True)
        alg_genetic = st.checkbox("Genetic Algorithm", value=True)
        alg_rl = st.checkbox("Reinforcement Learning", value=True)
        
        selected_algorithms = []
        if alg_dijkstra: selected_algorithms.append("Dijkstra")
        if alg_astar: selected_algorithms.append("A*")
        if alg_genetic: selected_algorithms.append("Genetic")
        if alg_rl: selected_algorithms.append("Reinforcement Learning")
        
        if st.button("🚀 Calculate Routes", type="primary"):
            if st.session_state.start_point and st.session_state.end_point and selected_algorithms:
                calculate_routes(api_key, selected_algorithms)
            else:
                st.error("Select start/end points and at least one algorithm")
    
    if st.session_state.routes_calculated and st.session_state.results:
        st.markdown("---")
        st.header("📊 Results Comparison")
        display_results()

def calculate_routes(api_key, selected_algorithms):
    with st.spinner("Calculating routes..."):
        results = {}
        start_point = st.session_state.start_point
        end_point = st.session_state.end_point
        dataset = st.session_state.dataset
        
        api_client = OpenRouteServiceClient(api_key) if api_key else None
        
        for algorithm in selected_algorithms:
            try:
                start_time = time.time()
                router = None
                
                if algorithm == "Dijkstra":
                    router = DijkstraRouter(dataset, api_client)
                elif algorithm == "A*":
                    router = AStarRouter(dataset, api_client)
                elif algorithm == "Genetic":
                    router = GeneticRouter(dataset, api_client)
                elif algorithm == "Reinforcement Learning":
                    router = RLRouter(dataset, api_client)
                
                if router is None:
                    continue
                    
                route_result = router.find_route(start_point, end_point)
                computation_time = time.time() - start_time
                
                results[algorithm] = {
                    'route': route_result['route'],
                    'distance_km': route_result['distance_km'],
                    'time_minutes': route_result['time_minutes'],
                    'computation_time': computation_time,
                    'adaptability_score': route_result.get('adaptability_score', 0.5)
                }
                
            except Exception as e:
                st.error(f"Error in {algorithm}: {str(e)}")
                results[algorithm] = None
        
        st.session_state.results = results
        st.session_state.routes_calculated = True
        st.rerun()

def display_results():
    results = st.session_state.results
    valid_results = {k: v for k, v in results.items() if v is not None}
    
    if not valid_results:
        st.error("No routes calculated successfully.")
        return
    
    st.subheader("Performance Table")
    
    comparison_data = []
    for algorithm, result in valid_results.items():
        comparison_data.append({
            'Algorithm': algorithm,
            'Distance (km)': f"{result['distance_km']:.2f}",
            'Time (min)': f"{result['time_minutes']:.1f}",
            'Computation (s)': f"{result['computation_time']:.3f}",
            'Adaptability': f"{result['adaptability_score']:.2f}"
        })
    
    df_comparison = pd.DataFrame(comparison_data)
    st.dataframe(df_comparison, use_container_width=True)
    
    best_distance = min(valid_results.items(), key=lambda x: x[1]['distance_km'])
    best_time = min(valid_results.items(), key=lambda x: x[1]['time_minutes'])
    best_computation = min(valid_results.items(), key=lambda x: x[1]['computation_time'])
    best_adaptability = max(valid_results.items(), key=lambda x: x[1]['adaptability_score'])
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("🏆 Best Distance", best_distance[0], f"{best_distance[1]['distance_km']:.2f} km")
    with col2:
        st.metric("⚡ Best Time", best_time[0], f"{best_time[1]['time_minutes']:.1f} min")
    with col3:
        st.metric("💨 Fastest Calc", best_computation[0], f"{best_computation[1]['computation_time']:.3f} s")
    with col4:
        st.metric("🔄 Most Adaptable", best_adaptability[0], f"{best_adaptability[1]['adaptability_score']:.2f}")
    
    st.subheader("Performance Charts")
    
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=['Distance (km)', 'Time (min)', 'Computation Time (s)', 'Adaptability Score'],
        specs=[[{"type": "bar"}, {"type": "bar"}],
               [{"type": "bar"}, {"type": "bar"}]]
    )
    
    algorithms = list(valid_results.keys())
    distances = [valid_results[alg]['distance_km'] for alg in algorithms]
    times = [valid_results[alg]['time_minutes'] for alg in algorithms]
    comp_times = [valid_results[alg]['computation_time'] for alg in algorithms]
    adaptability = [valid_results[alg]['adaptability_score'] for alg in algorithms]
    
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728']
    
    fig.add_trace(go.Bar(x=algorithms, y=distances, name='Distance', marker_color=colors[0]), row=1, col=1)
    fig.add_trace(go.Bar(x=algorithms, y=times, name='Time', marker_color=colors[1]), row=1, col=2)
    fig.add_trace(go.Bar(x=algorithms, y=comp_times, name='Computation', marker_color=colors[2]), row=2, col=1)
    fig.add_trace(go.Bar(x=algorithms, y=adaptability, name='Adaptability', marker_color=colors[3]), row=2, col=2)
    
    fig.update_layout(height=600, showlegend=False)
    st.plotly_chart(fig, use_container_width=True)
    
    st.subheader("Route Visualization")
    
    route_map = create_base_map()
    
    folium.Marker(
        location=st.session_state.start_point,
        popup="Start",
        icon=folium.Icon(color='green', icon='play')
    ).add_to(route_map)
    
    folium.Marker(
        location=st.session_state.end_point,
        popup="End",
        icon=folium.Icon(color='red', icon='stop')
    ).add_to(route_map)
    
    colors_map = {'Dijkstra': 'blue', 'A*': 'orange', 'Genetic': 'green', 'Reinforcement Learning': 'red'}
    
    for algorithm, result in valid_results.items():
        if result['route']:
            add_route_to_map(route_map, result['route'], colors_map.get(algorithm, 'purple'), algorithm)
    
    st_folium(route_map, width=800, height=400, key="results_map")

if __name__ == "__main__":
    main()
