import networkx as nx
import numpy as np
from geopy.distance import geodesic
import heapq
import math

class AStarRouter:
    """A* algorithm implementation for route optimization"""
    
    def __init__(self, dataset=None, api_client=None):
        self.dataset = dataset
        self.api_client = api_client
        self.graph = None
        
    def build_graph(self, points):
        """Build a graph from the given points"""
        G = nx.Graph()
        
        # Add nodes
        for i, point in enumerate(points):
            G.add_node(i, pos=point)
        
        # Add edges with distances as weights
        for i in range(len(points)):
            for j in range(i + 1, len(points)):
                distance = geodesic(points[i], points[j]).kilometers
                G.add_edge(i, j, weight=distance)
        
        return G
    
    def heuristic(self, point1, point2):
        """Calculate heuristic distance (straight-line distance)"""
        return geodesic(point1, point2).kilometers
    
    def find_route(self, start_point, end_point):
        """Find the optimal route using A* algorithm"""
        try:
            # If API client is available, use real routing
            if self.api_client:
                return self._find_route_with_api(start_point, end_point)
            
            # Otherwise, use graph-based approach with dataset
            if self.dataset is not None:
                return self._find_route_with_dataset(start_point, end_point)
            
            # Fallback: direct route
            return self._direct_route(start_point, end_point)
            
        except Exception as e:
            raise Exception(f"A* routing failed: {str(e)}")
    
    def _find_route_with_api(self, start_point, end_point):
        """Find route using API service with A* optimization hints"""
        route_data = self.api_client.get_route(start_point, end_point, profile='driving-car')
        
        return {
            'route': route_data['geometry'],
            'distance_km': route_data['distance'] / 1000,
            'time_minutes': route_data['duration'] / 60,
            'adaptability_score': 0.8  # A* is more adaptable than Dijkstra
        }
    
    def _find_route_with_dataset(self, start_point, end_point):
        """Find route using dataset points and A* algorithm"""
        # Create points list including start, end, and dataset points
        points = [start_point, end_point]
        if len(self.dataset) > 0:
            dataset_points = [[row['lat'], row['lon']] for _, row in self.dataset.iterrows()]
            points.extend(dataset_points[:50])  # Limit to 50 points for performance
        
        # Build graph
        self.graph = self.build_graph(points)
        
        # Find shortest path using A*
        try:
            path = self._astar_custom(self.graph, 0, 1, points)
            path_length = self._calculate_path_length(path, points)
        except Exception:
            # Direct route if A* fails
            return self._direct_route(start_point, end_point)
        
        # Convert path to coordinates
        route_coords = []
        for node in path:
            route_coords.append(points[node])
        
        # Calculate estimated time (assuming 55 km/h average speed for optimized route)
        time_minutes = (path_length / 55) * 60
        
        return {
            'route': route_coords,
            'distance_km': path_length,
            'time_minutes': time_minutes,
            'adaptability_score': 0.8
        }
    
    def _direct_route(self, start_point, end_point):
        """Calculate direct route between two points"""
        distance = geodesic(start_point, end_point).kilometers
        time_minutes = (distance / 55) * 60  # A* assumes slightly faster routing
        
        return {
            'route': [start_point, end_point],
            'distance_km': distance,
            'time_minutes': time_minutes,
            'adaptability_score': 0.6  # Better than direct Dijkstra due to heuristic
        }
    
    def _astar_custom(self, graph, start, goal, points):
        """Custom A* implementation"""
        open_set = [(0, start)]
        came_from = {}
        g_score = {node: float('infinity') for node in graph.nodes()}
        g_score[start] = 0
        f_score = {node: float('infinity') for node in graph.nodes()}
        f_score[start] = self.heuristic(points[start], points[goal])
        
        while open_set:
            current_f, current = heapq.heappop(open_set)
            
            if current == goal:
                # Reconstruct path
                path = [current]
                while current in came_from:
                    current = came_from[current]
                    path.append(current)
                return list(reversed(path))
            
            for neighbor in graph.neighbors(current):
                tentative_g_score = g_score[current] + graph[current][neighbor]['weight']
                
                if tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = g_score[neighbor] + self.heuristic(points[neighbor], points[goal])
                    
                    if (f_score[neighbor], neighbor) not in open_set:
                        heapq.heappush(open_set, (f_score[neighbor], neighbor))
        
        raise Exception("No path found")
    
    def _calculate_path_length(self, path, points):
        """Calculate total path length"""
        total_length = 0
        for i in range(len(path) - 1):
            total_length += geodesic(points[path[i]], points[path[i + 1]]).kilometers
        return total_length
