import pandas as pd
import numpy as np
import random

def process_uploaded_data(uploaded_file, lat_col='lat', lon_col='lon'):
    """Process uploaded CSV data and standardize column names"""
    try:
        # Read CSV file
        df = pd.read_csv(uploaded_file)
        
        # Validate required columns exist
        if lat_col not in df.columns or lon_col not in df.columns:
            raise ValueError(f"Required columns '{lat_col}' and '{lon_col}' not found in dataset")
        
        # Rename columns to standard names
        df = df.rename(columns={lat_col: 'lat', lon_col: 'lon'})
        
        # Validate coordinate ranges
        df = validate_coordinates(df)
        
        # Remove duplicates
        df = df.drop_duplicates(subset=['lat', 'lon'])
        
        return df
        
    except Exception as e:
        raise Exception(f"Error processing uploaded data: {str(e)}")

def validate_coordinates(df):
    """Validate latitude and longitude coordinates"""
    # Check for valid latitude range (-90 to 90)
    invalid_lat = (df['lat'] < -90) | (df['lat'] > 90)
    if invalid_lat.any():
        print(f"Warning: Removing {invalid_lat.sum()} rows with invalid latitude values")
        df = df[~invalid_lat]
    
    # Check for valid longitude range (-180 to 180)
    invalid_lon = (df['lon'] < -180) | (df['lon'] > 180)
    if invalid_lon.any():
        print(f"Warning: Removing {invalid_lon.sum()} rows with invalid longitude values")
        df = df[~invalid_lon]
    
    # Check for null values
    null_coords = df['lat'].isnull() | df['lon'].isnull()
    if null_coords.any():
        print(f"Warning: Removing {null_coords.sum()} rows with null coordinates")
        df = df[~null_coords]
    
    return df

def generate_sample_data(num_points=50, center_lat=51.5074, center_lon=-0.1278, radius_km=20):
    """Generate sample location data for testing"""
    
    # Convert radius from km to degrees (approximate)
    radius_deg = radius_km / 111.0  # 1 degree ≈ 111 km
    
    locations = []
    location_names = [
        "Central Station", "Airport", "Shopping Mall", "University", "Hospital",
        "Park", "Museum", "Stadium", "Hotel", "Restaurant", "Office Complex",
        "Library", "Theater", "School", "Pharmacy", "Bank", "Post Office",
        "Police Station", "Fire Station", "Bus Terminal", "Train Station",
        "Grocery Store", "Gas Station", "Church", "Gym", "Cinema", "Cafe",
        "Bookstore", "Market", "Clinic", "Embassy", "Gallery", "Workshop",
        "Factory", "Warehouse", "Marina", "Beach", "Observatory", "Zoo",
        "Aquarium", "Convention Center", "Sports Center", "Community Center",
        "Senior Center", "Youth Center", "Research Center", "Data Center",
        "Call Center", "Service Center", "Distribution Center"
    ]
    
    for i in range(num_points):
        # Generate random point within radius using uniform distribution
        # Convert to Cartesian, generate uniform point in circle, convert back
        angle = random.uniform(0, 2 * np.pi)
        distance = radius_deg * np.sqrt(random.uniform(0, 1))
        
        lat = center_lat + distance * np.cos(angle)
        lon = center_lon + distance * np.sin(angle)
        
        locations.append({
            'lat': round(lat, 6),
            'lon': round(lon, 6),
            'name': location_names[i % len(location_names)],
            'id': f"LOC_{i:03d}"
        })
    
    df = pd.DataFrame(locations)
    return df

def detect_coordinate_columns(df):
    """Automatically detect latitude and longitude columns in a dataframe"""
    lat_candidates = []
    lon_candidates = []
    
    for col in df.columns:
        col_lower = col.lower()
        
        # Check for latitude columns
        if any(term in col_lower for term in ['lat', 'latitude']):
            lat_candidates.append(col)
        
        # Check for longitude columns  
        if any(term in col_lower for term in ['lon', 'lng', 'long', 'longitude']):
            lon_candidates.append(col)
    
    # Return best matches
    lat_col = lat_candidates[0] if lat_candidates else None
    lon_col = lon_candidates[0] if lon_candidates else None
    
    return lat_col, lon_col

def calculate_distance_matrix(df):
    """Calculate distance matrix between all points in dataset"""
    from geopy.distance import geodesic
    
    n = len(df)
    distance_matrix = np.zeros((n, n))
    
    for i in range(n):
        for j in range(i + 1, n):
            point1 = (df.iloc[i]['lat'], df.iloc[i]['lon'])
            point2 = (df.iloc[j]['lat'], df.iloc[j]['lon'])
            distance = geodesic(point1, point2).kilometers
            distance_matrix[i][j] = distance
            distance_matrix[j][i] = distance  # Symmetric matrix
    
    return distance_matrix

def filter_points_by_distance(df, center_point, max_distance_km):
    """Filter points within a certain distance from center point"""
    from geopy.distance import geodesic
    
    filtered_points = []
    
    for _, row in df.iterrows():
        point = (row['lat'], row['lon'])
        distance = geodesic(center_point, point).kilometers
        
        if distance <= max_distance_km:
            filtered_points.append(row)
    
    return pd.DataFrame(filtered_points) if filtered_points else pd.DataFrame(columns=df.columns)

def create_grid_points(min_lat, max_lat, min_lon, max_lon, grid_size=10):
    """Create a grid of points within given bounds"""
    lat_steps = np.linspace(min_lat, max_lat, grid_size)
    lon_steps = np.linspace(min_lon, max_lon, grid_size)
    
    points = []
    for i, lat in enumerate(lat_steps):
        for j, lon in enumerate(lon_steps):
            points.append({
                'lat': round(lat, 6),
                'lon': round(lon, 6),
                'name': f'Grid_{i}_{j}',
                'id': f'GRID_{i:02d}_{j:02d}'
            })
    
    return pd.DataFrame(points)

def export_results_to_csv(results, filename='route_comparison_results.csv'):
    """Export algorithm results to CSV file"""
    
    comparison_data = []
    for algorithm, result in results.items():
        if result:
            comparison_data.append({
                'Algorithm': algorithm,
                'Distance_km': result['distance_km'],
                'Time_minutes': result['time_minutes'],
                'Computation_time_seconds': result['computation_time'],
                'Adaptability_score': result['adaptability_score']
            })
    
    df = pd.DataFrame(comparison_data)
    df.to_csv(filename, index=False)
    return df
