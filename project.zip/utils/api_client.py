import requests
import time
from typing import List, Dict, Tuple, Optional
import os

class OpenRouteServiceClient:
    """Client for OpenRouteService API (free alternative to Google Maps)"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.openrouteservice.org"
        self.session = requests.Session()
        self.session.headers.update({
            'Authorization': api_key,
            'Content-Type': 'application/json'
        })
        
        # Rate limiting
        self.last_request_time = 0
        self.min_request_interval = 1.0  # 1 second between requests for free tier
        
    def _rate_limit(self):
        """Implement rate limiting for API requests"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.min_request_interval:
            sleep_time = self.min_request_interval - time_since_last
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def get_route(self, start_point: List[float], end_point: List[float], 
                  profile: str = 'driving-car') -> Dict:
        """
        Get route between two points
        
        Args:
            start_point: [latitude, longitude] of start point
            end_point: [latitude, longitude] of end point
            profile: routing profile (driving-car, foot-walking, cycling-regular)
            
        Returns:
            Dictionary with route information
        """
        self._rate_limit()
        
        # OpenRouteService expects [longitude, latitude] format
        coordinates = [
            [start_point[1], start_point[0]],  # start: [lon, lat]
            [end_point[1], end_point[0]]       # end: [lon, lat]
        ]
        
        url = f"{self.base_url}/v2/directions/{profile}/geojson"
        
        payload = {
            "coordinates": coordinates,
            "radiuses": [-1, -1],  # No radius limit
            "instructions": False,
            "geometry": True,
            "elevation": False
        }
        
        try:
            response = self.session.post(url, json=payload, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            
            # Extract route information
            if 'features' in data and len(data['features']) > 0:
                feature = data['features'][0]
                properties = feature['properties']
                geometry = feature['geometry']
                
                # Convert geometry coordinates back to [lat, lon] format
                route_coords = []
                if geometry['type'] == 'LineString':
                    for coord in geometry['coordinates']:
                        route_coords.append([coord[1], coord[0]])  # [lat, lon]
                
                return {
                    'geometry': route_coords,
                    'distance': properties['segments'][0]['distance'],  # in meters
                    'duration': properties['segments'][0]['duration'],  # in seconds
                    'profile': profile,
                    'status': 'success'
                }
            else:
                raise Exception("No route found in API response")
                
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 403:
                raise Exception("Invalid API key or quota exceeded")
            elif e.response.status_code == 429:
                raise Exception("Rate limit exceeded. Please wait before making more requests.")
            else:
                raise Exception(f"HTTP error: {e.response.status_code}")
                
        except requests.exceptions.RequestException as e:
            raise Exception(f"Request error: {str(e)}")
        except Exception as e:
            raise Exception(f"API error: {str(e)}")
    
    def get_multiple_routes(self, waypoints: List[List[float]], 
                          profile: str = 'driving-car') -> List[Dict]:
        """
        Get routes for multiple waypoints
        
        Args:
            waypoints: List of [latitude, longitude] points
            profile: routing profile
            
        Returns:
            List of route dictionaries
        """
        routes = []
        
        for i in range(len(waypoints) - 1):
            try:
                route = self.get_route(waypoints[i], waypoints[i + 1], profile)
                routes.append(route)
            except Exception as e:
                print(f"Failed to get route between waypoints {i} and {i+1}: {str(e)}")
                # Create fallback direct route
                routes.append(self._create_direct_route(waypoints[i], waypoints[i + 1]))
        
        return routes
    
    def _create_direct_route(self, start_point: List[float], end_point: List[float]) -> Dict:
        """Create a direct route between two points as fallback"""
        from geopy.distance import geodesic
        
        distance = geodesic(start_point, end_point).meters
        # Assume average speed of 50 km/h for driving
        duration = (distance / 1000) / 50 * 3600  # seconds
        
        return {
            'geometry': [start_point, end_point],
            'distance': distance,
            'duration': duration,
            'profile': 'direct',
            'status': 'fallback'
        }
    
    def get_isochrone(self, center_point: List[float], time_limit: int = 600, 
                     profile: str = 'driving-car') -> Dict:
        """
        Get isochrone (area reachable within time limit)
        
        Args:
            center_point: [latitude, longitude] of center
            time_limit: time limit in seconds
            profile: routing profile
            
        Returns:
            Isochrone polygon data
        """
        self._rate_limit()
        
        # OpenRouteService expects [longitude, latitude] format
        location = [center_point[1], center_point[0]]
        
        url = f"{self.base_url}/v2/isochrones/{profile}"
        
        payload = {
            "locations": [location],
            "range": [time_limit],
            "range_type": "time"
        }
        
        try:
            response = self.session.post(url, json=payload, timeout=30)
            response.raise_for_status()
            
            return response.json()
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Isochrone request error: {str(e)}")
    
    def get_matrix(self, points: List[List[float]], 
                   profile: str = 'driving-car') -> Dict:
        """
        Get distance/duration matrix between multiple points
        
        Args:
            points: List of [latitude, longitude] points
            profile: routing profile
            
        Returns:
            Matrix with distances and durations
        """
        self._rate_limit()
        
        # Convert to [longitude, latitude] format
        locations = [[point[1], point[0]] for point in points]
        
        url = f"{self.base_url}/v2/matrix/{profile}"
        
        payload = {
            "locations": locations,
            "metrics": ["distance", "duration"],
            "resolve_locations": "true"
        }
        
        try:
            response = self.session.post(url, json=payload, timeout=60)
            response.raise_for_status()
            
            return response.json()
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"Matrix request error: {str(e)}")
    
    def validate_api_key(self) -> bool:
        """Validate if the API key is working"""
        try:
            # Make a simple request to test the API key
            test_route = self.get_route([51.505, -0.09], [51.515, -0.1])
            return test_route.get('status') == 'success'
        except Exception:
            return False
    
    @staticmethod
    def get_free_api_key_info() -> str:
        """Return information about getting a free API key"""
        return """
        To get a free OpenRouteService API key:
        
        1. Visit: https://openrouteservice.org/
        2. Click "Sign Up" and create an account
        3. Go to your dashboard and generate a new API token
        4. Free tier includes:
           - 2,000 requests per day
           - 40 requests per minute
           - All routing services included
        
        5. Enter your API key in the sidebar of this application
        """
