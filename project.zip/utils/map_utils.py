import folium
import numpy as np

def create_base_map(center=None, zoom_start=10):
    """Create a base Folium map"""
    if center is None:
        center = [51.505, -0.09]  # Default to London
    
    m = folium.Map(
        location=center,
        zoom_start=zoom_start,
        tiles='OpenStreetMap'
    )
    
    return m

def add_route_to_map(map_obj, route_coords, color='blue', algorithm_name='Route'):
    """Add a route to the Folium map"""
    if not route_coords or len(route_coords) < 2:
        return
    
    # Convert route coordinates to list format if needed
    if isinstance(route_coords[0], dict):
        # Handle coordinate dictionaries from API responses
        coords_list = [[coord['lat'], coord['lng']] for coord in route_coords]
    else:
        # Handle coordinate lists
        coords_list = route_coords
    
    # Add route as polyline
    folium.PolyLine(
        locations=coords_list,
        color=color,
        weight=4,
        opacity=0.8,
        popup=f"{algorithm_name} Route"
    ).add_to(map_obj)
    
    # Add markers for start and end points
    if len(coords_list) >= 2:
        folium.Marker(
            location=coords_list[0],
            popup=f"{algorithm_name} Start",
            icon=folium.Icon(color='green' if algorithm_name == 'Best' else 'lightgray', icon='play', prefix='fa')
        ).add_to(map_obj)
        
        folium.Marker(
            location=coords_list[-1],
            popup=f"{algorithm_name} End",
            icon=folium.Icon(color='red' if algorithm_name == 'Best' else 'lightgray', icon='stop', prefix='fa')
        ).add_to(map_obj)

def add_dataset_points_to_map(map_obj, dataset, max_points=100):
    """Add dataset points to the map"""
    if dataset is None or len(dataset) == 0:
        return
    
    # Sample points if dataset is too large
    if len(dataset) > max_points:
        dataset = dataset.sample(n=max_points)
    
    for _, row in dataset.iterrows():
        folium.CircleMarker(
            location=[row['lat'], row['lon']],
            radius=3,
            popup=f"Data Point: {row['lat']:.4f}, {row['lon']:.4f}",
            color='blue',
            fill=True,
            fillColor='lightblue',
            fillOpacity=0.6
        ).add_to(map_obj)

def add_performance_legend(map_obj, results):
    """Add a performance legend to the map"""
    if not results:
        return
    
    # Create legend HTML
    legend_html = """
    <div style="position: fixed; 
                top: 10px; right: 10px; width: 300px; height: auto; 
                background-color: white; border:2px solid grey; z-index:9999; 
                font-size:14px; padding: 10px">
    <h4>Algorithm Performance</h4>
    """
    
    colors = {'Dijkstra': 'blue', 'A*': 'orange', 'Genetic': 'green', 'Reinforcement Learning': 'red'}
    
    for algorithm, result in results.items():
        if result:
            color = colors.get(algorithm, 'purple')
            legend_html += f"""
            <p><span style="color:{color}; font-weight:bold;">■</span> {algorithm}<br>
               Distance: {result['distance_km']:.2f} km<br>
               Time: {result['time_minutes']:.1f} min</p>
            """
    
    legend_html += "</div>"
    
    map_obj.get_root().html.add_child(folium.Element(legend_html))

def calculate_map_bounds(points):
    """Calculate appropriate map bounds for given points"""
    if not points or len(points) == 0:
        return None
    
    lats = [point[0] for point in points]
    lons = [point[1] for point in points]
    
    return {
        'min_lat': min(lats),
        'max_lat': max(lats),
        'min_lon': min(lons),
        'max_lon': max(lons),
        'center_lat': (min(lats) + max(lats)) / 2,
        'center_lon': (min(lons) + max(lons)) / 2
    }

def fit_map_to_bounds(map_obj, bounds, padding=0.1):
    """Fit map view to given bounds"""
    if not bounds:
        return
    
    lat_padding = (bounds['max_lat'] - bounds['min_lat']) * padding
    lon_padding = (bounds['max_lon'] - bounds['min_lon']) * padding
    
    map_obj.fit_bounds([
        [bounds['min_lat'] - lat_padding, bounds['min_lon'] - lon_padding],
        [bounds['max_lat'] + lat_padding, bounds['max_lon'] + lon_padding]
    ])
